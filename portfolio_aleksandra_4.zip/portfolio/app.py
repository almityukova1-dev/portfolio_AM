from flask import Flask, render_template, request, jsonify
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
import json
from datetime import datetime

app = Flask(__name__)

# ── Configure your email here ──────────────────────────────────────────────
RECIPIENT_EMAIL = "almityukova1@gmail.com"
# For Gmail: enable App Passwords in your Google account and paste the
# 16-char app password below (or use env vars for production).
SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USER = os.environ.get("SMTP_USER", "your_gmail@gmail.com")
SMTP_PASS = os.environ.get("SMTP_PASS", "your_app_password")
# ──────────────────────────────────────────────────────────────────────────


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/contact", methods=["POST"])
def contact():
    data = request.get_json()

    name    = data.get("name", "").strip()
    email   = data.get("email", "").strip()
    company = data.get("company", "").strip()
    kind    = data.get("kind", "").strip()       # consultation | interview | offer
    message = data.get("message", "").strip()

    if not all([name, email, message]):
        return jsonify({"ok": False, "error": "Заполните обязательные поля."}), 400

    # ── Save locally as fallback ───────────────────────────────────────────
    log_entry = {
        "ts": datetime.utcnow().isoformat(),
        "name": name, "email": email,
        "company": company, "kind": kind, "message": message,
    }
    with open("contacts_log.jsonl", "a") as f:
        f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")

    # ── Send email ─────────────────────────────────────────────────────────
    kind_labels = {
        "consultation": "Запрос на консультацию",
        "interview":    "Приглашение на интервью",
        "offer":        "Предложение о работе / проекте",
    }
    kind_label = kind_labels.get(kind, "Контакт с сайта")

    subject = f"[Portfolio] {kind_label} — {name}"

    body = f"""
Новое сообщение с сайта-портфолио
═══════════════════════════════════
Тип запроса : {kind_label}
Имя         : {name}
Email       : {email}
Компания    : {company or '—'}
Дата        : {datetime.utcnow().strftime('%d.%m.%Y %H:%M')} UTC
═══════════════════════════════════

{message}

───────────────────────────────────
Ответить на: {email}
"""

    try:
        msg = MIMEMultipart()
        msg["From"]    = SMTP_USER
        msg["To"]      = RECIPIENT_EMAIL
        msg["Subject"] = subject
        msg["Reply-To"] = email
        msg.attach(MIMEText(body, "plain", "utf-8"))

        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.ehlo()
            server.starttls()
            server.login(SMTP_USER, SMTP_PASS)
            server.send_message(msg)

        return jsonify({"ok": True})

    except Exception as e:
        # Even if email fails, the message is saved in contacts_log.jsonl
        print(f"Email error: {e}")
        return jsonify({"ok": True, "warn": "Saved locally; email delivery failed."})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
