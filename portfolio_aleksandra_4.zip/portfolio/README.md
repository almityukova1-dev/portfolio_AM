# Aleksandra Mitiukova — Portfolio Website

A clean, production-ready Flask portfolio site with a contact/enquiry form.

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Set your email credentials (Gmail recommended)
#    Option A – environment variables (recommended for production)
export SMTP_USER="your_gmail@gmail.com"
export SMTP_PASS="your_16char_app_password"

#    Option B – edit app.py lines 13-14 directly (dev only)

# 3. Run the development server
python app.py
# → open http://localhost:5000
```

## Gmail App Password Setup

1. Go to Google Account → Security → 2-Step Verification (must be ON)
2. Search "App passwords" → create one for "Mail"
3. Copy the 16-character password → set as `SMTP_PASS`

## Production Deployment

### Render / Railway / Fly.io (recommended free tier)
- Push this folder to GitHub
- Connect repo to Render → new Web Service
- Set env vars `SMTP_USER` and `SMTP_PASS` in the dashboard
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`

### VPS / Linux server
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:8000 app:app
# then reverse-proxy with nginx
```

## Form Submissions

All enquiries are:
1. Emailed to `almityukova1@gmail.com`
2. Saved locally to `contacts_log.jsonl` (failsafe backup)

## File Structure

```
portfolio/
├── app.py              # Flask app + email handler
├── requirements.txt
├── contacts_log.jsonl  # created automatically on first submission
└── templates/
    └── index.html      # full single-page site
```
